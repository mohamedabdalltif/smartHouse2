import axios from 'axios';

export default axios.create({
  baseURL: 'https://camp-coding.online/smart-shelves/',
  //   timeout: 30000,
});
