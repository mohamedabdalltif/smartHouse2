import Login from './Login';
import Signup from './Signup';
import SeconedStepVerify from './SeconedStepVerify';
import Faq from './Faq';
import ForgetPassword from './ForgetPassword';
// import NewPassword from './NewPassword';
import RegisterSuccess from './RegisterSuccess';
import SetupHome from './SetupHome';
import Country from './Country' ; 
import SignInHome from './SignInHome' ; 
export {
    SignInHome,
    Login,
    Signup,
    SeconedStepVerify,
    Faq,ForgetPassword,
    RegisterSuccess,
    SetupHome, 
    Country
   
};


